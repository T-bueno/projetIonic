export interface Entreprise {
  poste: string;
  adresse: string;
  nom: string;
  photo: string;
  codepostal: number;
}
