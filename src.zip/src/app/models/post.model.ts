export interface Entreprise {
    poste: string;
    adresse: string;
  }
