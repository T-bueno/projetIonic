import { Component } from "@angular/core";
import { AngularFirestore } from "@angular/fire/firestore";
import { ToastController, LoadingController, Platform } from "@ionic/angular";

@Component({
  selector: "app-offre",
  templateUrl: "offre.page.html",
  styleUrls: ["offre.page.scss"]
})
export class OffrePage {
  entreprise: any;
  subscription: any;
  count: number;


  constructor(
    private toastCtrl: ToastController,
    private firestore: AngularFirestore,
    private loadingCtrl: LoadingController,
    private platform: Platform
  ) {}

  ionViewDidEnter() {
    this.subscription = this.platform.backButton.subscribe(() => {
      navigator["app"].exitApp();
    });
  }

  ionViewWillLeave() {
    this.subscription.unsubscribe();
  }

  async getEntreprise() {
    // console.log("get entreprises");
    this.count = 0;

    // show loader
    let loader = await this.loadingCtrl.create({
      message: "Please wait..."
    });
    loader.present();

    try {
      this.firestore
        .collection('entreprise')
        .snapshotChanges()
        .subscribe(data => {
          this.entreprise = data.map(e => {
            this.count +=1;
            return {
              id: e.payload.doc.id,
              adresse: e.payload.doc.data()["adresse"],
              codepostal: e.payload.doc.data()["code_postal"],
              nom: e.payload.doc.data()["nom"],
              poste: e.payload.doc.data()["poste"],
              photo: e.payload.doc.data()["photo"]
            };
          });

          // dismiss loader
          loader.dismiss();
        });
    } catch (e) {
      this.showToast(e);
    }
  }

  async deleteEntreprise(id: string) {
    // console.log(id);

    // show loader
    let loader = await this.loadingCtrl.create({
      message: "Please wait..."
    });
    loader.present();

    await this.firestore.doc("entreprise/" + id).delete();

    // dismiss loader
    loader.dismiss();
  }

  ionViewWillEnter() {
    this.getEntreprise();
  }

  showToast(message: string) {
    this.toastCtrl
      .create({
        message: message,
        duration: 3000
      })
      .then(toastData => toastData.present());
  }
}
