import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidatures',
  templateUrl: './candidatures.page.html',
  styleUrls: ['./candidatures.page.scss'],
})
export class CandidaturesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
